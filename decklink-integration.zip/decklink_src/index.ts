// @ts-ignore
import { createRequire } from 'module';
import path from 'path';
import { fileURLToPath } from 'url';

export interface NativeMixerIntegration {
    getDeckLinkDevices?: () => { index: number, name: string }[];
    startMixer: () => void;
    startDeckLinkOutput: (deviceIndex?: number) => string;
    setDecklinkOutputSource?: (id: number) => void;
    startDeckLinkInput: (deviceIndex: number, sourceId: number, format: string) => string;
    addSource: (id: number) => void;
    pushSourceFrame: (id: number, rgbaBuffer: Buffer, width?: number, height?: number) => void;
    setProgramSource: (id: number) => void;
    setPipSource: (id: number, enabled: boolean) => void;
    setPreviewCallback: (cb: (buffer: Buffer) => void) => void;
    setVcamCallback: (cb: (buffer: Buffer) => void) => void;
    getSourceFrame: (id: number) => Buffer | null;
}

export function getNativeMixer(): NativeMixerIntegration | null {
    if (process.platform !== 'win32') {
        return null;
    }
    try {
        const req = typeof require !== 'undefined' ? require : createRequire(import.meta.url);
        
        let addonPath = '';
        if (typeof __dirname !== 'undefined') {
             addonPath = path.join(__dirname, '../build/Release/decklink.node');
             try {
                return req(addonPath);
             } catch(e) {}
        }
        
        // Fallback for dev mode
        addonPath = path.join(process.cwd(), 'build/Release/decklink.node');
        const addon = req(addonPath);
        return addon;
    } catch (e) {
        console.warn('[DeckLink] Native mixer addon not found.');
        return null;
    }
}
