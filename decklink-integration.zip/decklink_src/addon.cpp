#include <algorithm>
#include <string_view>
#include <napi.h>
#include <iostream>
#include <thread>
#include <atomic>
#include <mutex>
#include <vector>
#include <map>
#include <cstring>
#include <chrono>

#ifdef _WIN32
#include <objbase.h>
#endif
#include "DeckLinkAPI_h.h"
#include "DeckLinkAPIVersion.h"

using namespace std;

#ifdef _WIN32
HANDLE vcamSharedMemory = nullptr;
HANDLE vcamSharedEvent = nullptr;
HANDLE vcamSharedMutex = nullptr;
uint8_t* vcamSharedBuffer = nullptr;
size_t vcamBufferSize = 3840 * 2160 * 4;

void TryOpenVcamSharedMemory() {
    if (vcamSharedBuffer && vcamSharedEvent && vcamSharedMutex) return;

    if (!vcamSharedMemory) {
        vcamSharedMemory = OpenFileMappingA(FILE_MAP_WRITE, FALSE, "Global\\NodeVCamSharedBuffer");
        if (!vcamSharedMemory) vcamSharedMemory = OpenFileMappingA(FILE_MAP_WRITE, FALSE, "Local\\NodeVCamSharedBuffer");
    }
    if (vcamSharedMemory && !vcamSharedBuffer) {
        vcamSharedBuffer = (uint8_t*)MapViewOfFile(vcamSharedMemory, FILE_MAP_WRITE, 0, 0, vcamBufferSize);
    }

    if (!vcamSharedEvent) {
        vcamSharedEvent = OpenEventA(EVENT_MODIFY_STATE, FALSE, "Global\\NodeVCamSharedEvent");
        if (!vcamSharedEvent) vcamSharedEvent = OpenEventA(EVENT_MODIFY_STATE, FALSE, "Local\\NodeVCamSharedEvent");
    }
    
    if (!vcamSharedMutex) {
        vcamSharedMutex = OpenMutexA(MUTEX_ALL_ACCESS, FALSE, "Global\\NodeVCamSharedMutex");
        if (!vcamSharedMutex) vcamSharedMutex = OpenMutexA(MUTEX_ALL_ACCESS, FALSE, "Local\\NodeVCamSharedMutex");
    }
}
#endif
std::atomic<bool> vcamDirectEnabled{false};

// Configuration
const int MIXER_WIDTH = 1920;
const int MIXER_HEIGHT = 1080;
const int PREVIEW_WIDTH = 1920;
const int PREVIEW_HEIGHT = 1080;

// Source struct
struct VideoSource {
    int id;
    uint8_t* rgbaBuffer = nullptr;
    int width = 0;
    int height = 0;
    std::mutex lock;

    VideoSource(int _id) : id(_id) {
        rgbaBuffer = new uint8_t[MIXER_WIDTH * MIXER_HEIGHT * 4];
        memset(rgbaBuffer, 0, MIXER_WIDTH * MIXER_HEIGHT * 4);
    }
    ~VideoSource() {
        delete[] rgbaBuffer;
    }
};

std::map<int, VideoSource*> sources;

std::map<int, IDeckLinkInput*> activeDeckLinkInputs;

std::mutex sourcesLock;

// Mixer State
int programSourceId = -1;
int pipSourceId = -1;
int decklinkOutputSourceId = -1;
bool isPipEnabled = false;

// DeckLink State
IDeckLinkOutput* deckLinkOutput = nullptr;
IDeckLinkMutableVideoFrame* videoFrame1 = nullptr;
IDeckLinkMutableVideoFrame* videoFrame2 = nullptr;
std::atomic<int> currentDisplayBuffer(0);

// Thread State
std::thread* mixerThread = nullptr;
std::atomic<bool> isRunning(false);

// Callbacks
Napi::ThreadSafeFunction previewCallback;
Napi::ThreadSafeFunction vcamCallback;

// Conversions
void ConvertRGBAToUYVY(const uint8_t* rgba, uint8_t* uyvy, int width, int height) {
    if (!rgba || !uyvy || width <= 0 || height <= 0) return;
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x += 2) {
            int rgbIdx1 = (y * width + x) * 4;
            int rgbIdx2 = (y * width + x + 1) * 4;
            int uyvyIdx = (y * width + x) * 2;

            uint8_t r1 = rgba[rgbIdx1], g1 = rgba[rgbIdx1+1], b1 = rgba[rgbIdx1+2];
            uint8_t r2 = rgba[rgbIdx2], g2 = rgba[rgbIdx2+1], b2 = rgba[rgbIdx2+2];

            int y1 = ((66 * r1 + 129 * g1 + 25 * b1 + 128) >> 8) + 16;
            int u1 = ((-38 * r1 - 74 * g1 + 112 * b1 + 128) >> 8) + 128;
            int v1 = ((112 * r1 - 94 * g1 - 18 * b1 + 128) >> 8) + 128;

            int y2 = ((66 * r2 + 129 * g2 + 25 * b2 + 128) >> 8) + 16;
            int u2 = ((-38 * r2 - 74 * g2 + 112 * b2 + 128) >> 8) + 128;
            int v2 = ((112 * r2 - 94 * g2 - 18 * b2 + 128) >> 8) + 128;

            uint8_t u = (u1 + u2) / 2;
            uint8_t v = (v1 + v2) / 2;

            uyvy[uyvyIdx] = u;
            uyvy[uyvyIdx+1] = std::clamp(y1, 16, 235);
            uyvy[uyvyIdx+2] = v;
            uyvy[uyvyIdx+3] = std::clamp(y2, 16, 235);
        }
    }
}

void ConvertUYVYToRGBA(const uint8_t* uyvy, uint8_t* rgba, int srcWidth, int srcHeight, int srcRowBytes, int dstWidth, int dstHeight) {
    if (!uyvy || !rgba || srcWidth <= 0 || srcHeight <= 0 || dstWidth <= 0 || dstHeight <= 0) return;
    int copyWidth = std::min(srcWidth, dstWidth);
    int copyHeight = std::min(srcHeight, dstHeight);
    
    for (int y = 0; y < copyHeight; y++) {
        const uint8_t* srcRow = uyvy + (y * srcRowBytes);
        uint8_t* dstRow = rgba + (y * dstWidth * 4);

        for (int x = 0; x < copyWidth; x += 2) {
            int uyvyIdx = x * 2;
            int rgbIdx1 = x * 4;
            int rgbIdx2 = (x + 1) * 4;

            int u = srcRow[uyvyIdx] - 128;
            int y1 = srcRow[uyvyIdx+1] - 16;
            int v = srcRow[uyvyIdx+2] - 128;
            int y2 = srcRow[uyvyIdx+3] - 16;

            int c1 = 298 * y1;
            int c2 = 298 * y2;
            int d = u;
            int e = v;

            dstRow[rgbIdx1]   = std::clamp((c1 + 409 * e + 128) >> 8, 0, 255);
            dstRow[rgbIdx1+1] = std::clamp((c1 - 100 * d - 208 * e + 128) >> 8, 0, 255);
            dstRow[rgbIdx1+2] = std::clamp((c1 + 516 * d + 128) >> 8, 0, 255);
            dstRow[rgbIdx1+3] = 255;

            if (x + 1 < copyWidth) {
                dstRow[rgbIdx2]   = std::clamp((c2 + 409 * e + 128) >> 8, 0, 255);
                dstRow[rgbIdx2+1] = std::clamp((c2 - 100 * d - 208 * e + 128) >> 8, 0, 255);
                dstRow[rgbIdx2+2] = std::clamp((c2 + 516 * d + 128) >> 8, 0, 255);
                dstRow[rgbIdx2+3] = 255;
            }
        }
    }
}

// 10-Bit YUV 4:2:2 (v210) Decoder - Used on Professional / Broadcast & Medical SDI feeds
void ConvertV210ToRGBA(const uint8_t* v210, uint8_t* rgba, int srcWidth, int srcHeight, int srcRowBytes, int dstWidth, int dstHeight) {
    if (!v210 || !rgba || srcWidth <= 0 || srcHeight <= 0 || dstWidth <= 0 || dstHeight <= 0) return;
    int copyWidth = std::min(srcWidth, dstWidth);
    int copyHeight = std::min(srcHeight, dstHeight);

    for (int y = 0; y < copyHeight; y++) {
        const uint32_t* srcRow = (const uint32_t*)(v210 + (y * srcRowBytes));
        uint8_t* dstRow = rgba + (y * dstWidth * 4);

        int blocks = copyWidth / 6;
        for (int b = 0; b < blocks; b++) {
            uint32_t w0 = srcRow[b * 4 + 0];
            uint32_t w1 = srcRow[b * 4 + 1];
            uint32_t w2 = srcRow[b * 4 + 2];
            uint32_t w3 = srcRow[b * 4 + 3];

            // Extract 10-bit samples to 8-bit
            int u0 = ((w0 >> 0) & 0x3FF) >> 2;
            int y0 = ((w0 >> 10) & 0x3FF) >> 2;
            int v0 = ((w0 >> 20) & 0x3FF) >> 2;

            int y1 = ((w1 >> 0) & 0x3FF) >> 2;
            int u1 = ((w1 >> 10) & 0x3FF) >> 2;
            int y2 = ((w1 >> 20) & 0x3FF) >> 2;

            int v1 = ((w2 >> 0) & 0x3FF) >> 2;
            int y3 = ((w2 >> 10) & 0x3FF) >> 2;
            int u2 = ((w2 >> 20) & 0x3FF) >> 2;

            int y4 = ((w3 >> 0) & 0x3FF) >> 2;
            int v2 = ((w3 >> 10) & 0x3FF) >> 2;
            int y5 = ((w3 >> 20) & 0x3FF) >> 2;

            int y_arr[6] = { y0, y1, y2, y3, y4, y5 };
            int u_arr[6] = { u0, u0, u1, u1, u2, u2 };
            int v_arr[6] = { v0, v0, v1, v1, v2, v2 };

            for (int p = 0; p < 6; p++) {
                int px = b * 6 + p;
                if (px >= copyWidth) break;

                int y_val = y_arr[p] - 16;
                int u_val = u_arr[p] - 128;
                int v_val = v_arr[p] - 128;

                int c = 298 * y_val;
                int d = u_val;
                int e = v_val;

                int outIdx = px * 4;
                dstRow[outIdx]     = std::clamp((c + 409 * e + 128) >> 8, 0, 255);
                dstRow[outIdx + 1] = std::clamp((c - 100 * d - 208 * e + 128) >> 8, 0, 255);
                dstRow[outIdx + 2] = std::clamp((c + 516 * d + 128) >> 8, 0, 255);
                dstRow[outIdx + 3] = 255;
            }
        }
    }
}

void ConvertBGRAToRGBA(const uint8_t* bgra, uint8_t* rgba, int srcWidth, int srcHeight, int srcRowBytes, int dstWidth, int dstHeight) {
    if (!bgra || !rgba || srcWidth <= 0 || srcHeight <= 0 || dstWidth <= 0 || dstHeight <= 0) return;
    int copyWidth = std::min(srcWidth, dstWidth);
    int copyHeight = std::min(srcHeight, dstHeight);

    for (int y = 0; y < copyHeight; y++) {
        const uint8_t* srcRow = bgra + (y * srcRowBytes);
        uint8_t* dstRow = rgba + (y * dstWidth * 4);
        for (int x = 0; x < copyWidth; x++) {
            dstRow[x * 4 + 0] = srcRow[x * 4 + 2]; // R
            dstRow[x * 4 + 1] = srcRow[x * 4 + 1]; // G
            dstRow[x * 4 + 2] = srcRow[x * 4 + 0]; // B
            dstRow[x * 4 + 3] = 255;
        }
    }
}

void ConvertARGBToRGBA(const uint8_t* argb, uint8_t* rgba, int srcWidth, int srcHeight, int srcRowBytes, int dstWidth, int dstHeight) {
    if (!argb || !rgba || srcWidth <= 0 || srcHeight <= 0 || dstWidth <= 0 || dstHeight <= 0) return;
    int copyWidth = std::min(srcWidth, dstWidth);
    int copyHeight = std::min(srcHeight, dstHeight);

    for (int y = 0; y < copyHeight; y++) {
        const uint8_t* srcRow = argb + (y * srcRowBytes);
        uint8_t* dstRow = rgba + (y * dstWidth * 4);
        for (int x = 0; x < copyWidth; x++) {
            dstRow[x * 4 + 0] = srcRow[x * 4 + 1]; // R
            dstRow[x * 4 + 1] = srcRow[x * 4 + 2]; // G
            dstRow[x * 4 + 2] = srcRow[x * 4 + 3]; // B
            dstRow[x * 4 + 3] = 255;
        }
    }
}

void Convert10BitRGBToRGBA(const uint8_t* r210, uint8_t* rgba, int srcWidth, int srcHeight, int srcRowBytes, int dstWidth, int dstHeight) {
    if (!r210 || !rgba || srcWidth <= 0 || srcHeight <= 0 || dstWidth <= 0 || dstHeight <= 0) return;
    int copyWidth = std::min(srcWidth, dstWidth);
    int copyHeight = std::min(srcHeight, dstHeight);

    for (int y = 0; y < copyHeight; y++) {
        const uint32_t* srcRow = (const uint32_t*)(r210 + (y * srcRowBytes));
        uint8_t* dstRow = rgba + (y * dstWidth * 4);

        for (int x = 0; x < copyWidth; x++) {
            uint32_t pixel = srcRow[x];
            // Blackmagic 10-Bit RGB (r210): [31:30 unused] [29:20 R] [19:10 G] [9:0 B]
            uint8_t r = (pixel >> 22) & 0xFF;
            uint8_t g = (pixel >> 12) & 0xFF;
            uint8_t b = (pixel >> 2) & 0xFF;

            int dstIdx = x * 4;
            dstRow[dstIdx + 0] = r;
            dstRow[dstIdx + 1] = g;
            dstRow[dstIdx + 2] = b;
            dstRow[dstIdx + 3] = 255;
        }
    }
}

void ConvertRGBAToRGBA(const uint8_t* srcRgba, uint8_t* rgba, int srcWidth, int srcHeight, int srcRowBytes, int dstWidth, int dstHeight) {
    if (!srcRgba || !rgba || srcWidth <= 0 || srcHeight <= 0 || dstWidth <= 0 || dstHeight <= 0) return;
    int copyWidth = std::min(srcWidth, dstWidth);
    int copyHeight = std::min(srcHeight, dstHeight);

    for (int y = 0; y < copyHeight; y++) {
        const uint8_t* srcRow = srcRgba + (y * srcRowBytes);
        uint8_t* dstRow = rgba + (y * dstWidth * 4);
        memcpy(dstRow, srcRow, copyWidth * 4);
    }
}

void ConvertRgbaToNv12(const uint8_t* rgba, int width, int height, uint8_t* nv12) {
    if (!rgba || !nv12 || width <= 0 || height <= 0) return;
    int frameSize = width * height;
    uint8_t* yPlane = nv12;
    uint8_t* uvPlane = nv12 + frameSize;
    
    // Process 2 rows at a time
    for (int j = 0; j < height; j += 2) {
        uint8_t* yRow1 = yPlane + j * width;
        uint8_t* yRow2 = yPlane + (j + 1) * width;
        uint8_t* uvRow = uvPlane + (j / 2) * width;
        
        const uint8_t* rgbaRow1 = rgba + j * width * 4;
        const uint8_t* rgbaRow2 = rgba + (j + 1) * width * 4;
        
        // Process 2 pixels (a 2x2 block) per loop iteration
        for (int i = 0; i < width; i += 2) {
            int i4 = i * 4;
            // Pixel 0,0
            int r00 = rgbaRow1[i4 + 0], g00 = rgbaRow1[i4 + 1], b00 = rgbaRow1[i4 + 2];
            yRow1[i] = (uint8_t)(((66 * r00 + 129 * g00 + 25 * b00 + 128) >> 8) + 16);
            
            // Pixel 0,1
            int r01 = rgbaRow1[i4 + 4], g01 = rgbaRow1[i4 + 5], b01 = rgbaRow1[i4 + 6];
            yRow1[i + 1] = (uint8_t)(((66 * r01 + 129 * g01 + 25 * b01 + 128) >> 8) + 16);

            // Pixel 1,0
            int r10 = rgbaRow2[i4 + 0], g10 = rgbaRow2[i4 + 1], b10 = rgbaRow2[i4 + 2];
            yRow2[i] = (uint8_t)(((66 * r10 + 129 * g10 + 25 * b10 + 128) >> 8) + 16);

            // Pixel 1,1
            int r11 = rgbaRow2[i4 + 4], g11 = rgbaRow2[i4 + 5], b11 = rgbaRow2[i4 + 6];
            yRow2[i + 1] = (uint8_t)(((66 * r11 + 129 * g11 + 25 * b11 + 128) >> 8) + 16);

            // U and V calculated from the average of the 2x2 block
            int r_avg = (r00 + r01 + r10 + r11) >> 2;
            int g_avg = (g00 + g01 + g10 + g11) >> 2;
            int b_avg = (b00 + b01 + b10 + b11) >> 2;

            int u = (32768 - 38 * r_avg - 74 * g_avg + 112 * b_avg) >> 8;
            int v = (32768 + 112 * r_avg - 94 * g_avg - 18 * b_avg) >> 8;
            
            uvRow[i] = (uint8_t)(u > 255 ? 255 : (u < 0 ? 0 : u));
            uvRow[i + 1] = (uint8_t)(v > 255 ? 255 : (v < 0 ? 0 : v));
        }
    }
}

void DownscaleRGBA(const uint8_t* src, uint8_t* dst, int srcW, int srcH, int dstW, int dstH) {
    if (!src || !dst || srcW <= 0 || srcH <= 0 || dstW <= 0 || dstH <= 0) return;
    float xRatio = ((float)(srcW - 1)) / dstW;
    float yRatio = ((float)(srcH - 1)) / dstH;
    for (int i = 0; i < dstH; i++) {
        for (int j = 0; j < dstW; j++) {
            int x = (int)(xRatio * j);
            int y = (int)(yRatio * i);
            int srcIdx = (y * srcW + x) * 4;
            int dstIdx = (i * dstW + j) * 4;
            dst[dstIdx] = src[srcIdx];
            dst[dstIdx+1] = src[srcIdx+1];
            dst[dstIdx+2] = src[srcIdx+2];
            dst[dstIdx+3] = 255;
        }
    }
}

class DeckLinkInputCallback : public IDeckLinkInputCallback {
public:
    int sourceId;
    ULONG refCount = 1;
    IDeckLinkInput* deckLinkInput;

    DeckLinkInputCallback(int id, IDeckLinkInput* input) : sourceId(id), deckLinkInput(input) {}
    
    HRESULT STDMETHODCALLTYPE QueryInterface(REFIID iid, LPVOID *ppv) override {
        if (!ppv) return E_POINTER;
        if (iid == IID_IDeckLinkInputCallback || iid == IID_IUnknown) {
            *ppv = this;
            AddRef();
            return S_OK;
        }
        *ppv = nullptr;
        return E_NOINTERFACE;
    }
    
    ULONG STDMETHODCALLTYPE AddRef() override {
        return ++refCount;
    }
    
    ULONG STDMETHODCALLTYPE Release() override {
        ULONG newRef = --refCount;
        if (newRef == 0) delete this;
        return newRef;
    }
    
    HRESULT STDMETHODCALLTYPE VideoInputFormatChanged(BMDVideoInputFormatChangedEvents events, IDeckLinkDisplayMode *displayMode, BMDDetectedVideoInputFormatFlags detectedSignalFlags) override {
        if (!deckLinkInput || !displayMode) return S_OK;
        
        if (!(events & bmdVideoInputDisplayModeChanged) && !(events & bmdVideoInputColorspaceChanged)) {
            return S_OK;
        }

        BMDDisplayMode mode = displayMode->GetDisplayMode();
        BMDPixelFormat pixelFormat = bmdFormat8BitYUV;
        if (detectedSignalFlags & bmdDetectedVideoInputRGB444) {
            pixelFormat = bmdFormat8BitARGB;
        }

        IDeckLinkInput* dl = deckLinkInput;
        std::thread([dl, mode, pixelFormat]() {
            dl->PauseStreams();
            dl->EnableVideoInput(mode, pixelFormat, bmdVideoInputEnableFormatDetection);
            dl->FlushStreams();
            dl->StartStreams();
        }).detach();
        return S_OK;
    }
    
    HRESULT STDMETHODCALLTYPE VideoInputFrameArrived(IDeckLinkVideoInputFrame* videoFrame, IDeckLinkAudioInputPacket* audioPacket) override {
        if (!videoFrame) return S_OK;

        BMDFrameFlags flags = videoFrame->GetFlags();
        if (flags & bmdFrameHasNoInputSource) {
            return S_OK;
        }

        long width = videoFrame->GetWidth();
        long height = videoFrame->GetHeight();
        long rowBytes = videoFrame->GetRowBytes();
        BMDPixelFormat pixelFormat = videoFrame->GetPixelFormat();

        if (width <= 0 || height <= 0) return S_OK;

        void* bytes = nullptr;
        if (videoFrame->GetBytes(&bytes) != S_OK) {
            bytes = nullptr;
        }

        static int frameCount = 0;
        if (frameCount++ % 100 == 0) {
            printf("[DeckLink] Frame Arrived! width=%ld, height=%ld, flags=%d, bytes=%p\n", width, height, flags, bytes);
        }

        if (bytes != nullptr) {
            VideoSource* src = nullptr;
            {
                std::lock_guard<std::mutex> lock(sourcesLock);
                if (sources.count(sourceId) && sources[sourceId]) {
                    src = sources[sourceId];
                }
            }
            if (src && src->rgbaBuffer) {
                std::lock_guard<std::mutex> srcLock(src->lock);
                    
                    if (pixelFormat == bmdFormat8BitYUV) {
                        ConvertUYVYToRGBA((const uint8_t*)bytes, src->rgbaBuffer, (int)width, (int)height, (int)rowBytes, MIXER_WIDTH, MIXER_HEIGHT);
                    } else if (pixelFormat == bmdFormat10BitYUV) {
                        ConvertV210ToRGBA((const uint8_t*)bytes, src->rgbaBuffer, (int)width, (int)height, (int)rowBytes, MIXER_WIDTH, MIXER_HEIGHT);
                    } else if (pixelFormat == bmdFormat10BitRGB) {
                        Convert10BitRGBToRGBA((const uint8_t*)bytes, src->rgbaBuffer, (int)width, (int)height, (int)rowBytes, MIXER_WIDTH, MIXER_HEIGHT);
                    } else if (pixelFormat == bmdFormat8BitARGB) {
                        ConvertARGBToRGBA((const uint8_t*)bytes, src->rgbaBuffer, (int)width, (int)height, (int)rowBytes, MIXER_WIDTH, MIXER_HEIGHT);
                    } else if (pixelFormat == bmdFormat8BitBGRA) {
                        ConvertBGRAToRGBA((const uint8_t*)bytes, src->rgbaBuffer, (int)width, (int)height, (int)rowBytes, MIXER_WIDTH, MIXER_HEIGHT);
                    } else {
                        ConvertUYVYToRGBA((const uint8_t*)bytes, src->rgbaBuffer, (int)width, (int)height, (int)rowBytes, MIXER_WIDTH, MIXER_HEIGHT);
                    }

                    if (programSourceId == -1) {
                        programSourceId = sourceId;
                    }
            }
        }

        return S_OK;
    }
};

static int globalFrameCount = 0;
void MixerLoop() {
#ifdef _WIN32
    CoInitializeEx(NULL, COINIT_MULTITHREADED);
#endif
    uint8_t* mixBuffer = new uint8_t[MIXER_WIDTH * MIXER_HEIGHT * 4];
    uint8_t* previewBuffer = new uint8_t[PREVIEW_WIDTH * PREVIEW_HEIGHT * 4];
#ifdef _WIN32
    uint32_t* vcamBgraBuffer = new uint32_t[MIXER_WIDTH * MIXER_HEIGHT];
#endif
    
    auto nextFrameTime = std::chrono::steady_clock::now();

    while (isRunning) {
        memset(mixBuffer, 0, MIXER_WIDTH * MIXER_HEIGHT * 4);

        if (programSourceId != -1) {
            VideoSource* src = nullptr;
            {
                std::lock_guard<std::mutex> lock(sourcesLock);
                if (sources.count(programSourceId)) src = sources[programSourceId];
            }
            if (src) {
                std::lock_guard<std::mutex> srcLock(src->lock);
                memcpy(mixBuffer, src->rgbaBuffer, MIXER_WIDTH * MIXER_HEIGHT * 4);
            }
        }

        if (isPipEnabled && pipSourceId != -1) {
            VideoSource* src = nullptr;
            {
                std::lock_guard<std::mutex> lock(sourcesLock);
                if (sources.count(pipSourceId)) src = sources[pipSourceId];
            }
            if (src) {
                std::lock_guard<std::mutex> srcLock(src->lock);
                int pipW = MIXER_WIDTH / 3;
                int pipH = MIXER_HEIGHT / 3;
                int pipX = MIXER_WIDTH - pipW - 40;
                int pipY = MIXER_HEIGHT - pipH - 40;
                
                for (int y = 0; y < pipH; y++) {
                    for (int x = 0; x < pipW; x++) {
                        int srcX = x * 3;
                        int srcY = y * 3;
                        int srcIdx = (srcY * MIXER_WIDTH + srcX) * 4;
                        int dstIdx = ((pipY + y) * MIXER_WIDTH + (pipX + x)) * 4;
                        mixBuffer[dstIdx] = src->rgbaBuffer[srcIdx];
                        mixBuffer[dstIdx+1] = src->rgbaBuffer[srcIdx+1];
                        mixBuffer[dstIdx+2] = src->rgbaBuffer[srcIdx+2];
                        mixBuffer[dstIdx+3] = 255;
                    }
                }
            }
        }
        
        {
            VideoSource* src = nullptr;
            {
                std::lock_guard<std::mutex> lock(sourcesLock);
                if (sources.count(9999)) src = sources[9999];
            }
            if (src) {
                std::lock_guard<std::mutex> srcLock(src->lock);
                uint32_t* dst32 = (uint32_t*)mixBuffer;
                uint32_t* src32 = (uint32_t*)src->rgbaBuffer;
                for (int i = 0; i < MIXER_WIDTH * MIXER_HEIGHT; i++) {
                    uint32_t p = src32[i];
                    uint8_t a = p >> 24;
                    uint8_t sR = p & 0xFF;
                    uint8_t sG = (p >> 8) & 0xFF;
                    uint8_t sB = (p >> 16) & 0xFF;
                    
                    if (a > 0 && (sR > 10 || sG > 10 || sB > 10)) { // Luma key black out
                        if (a == 255) {
                            dst32[i] = p;
                        } else {
                            uint32_t d = dst32[i];
                            uint8_t dR = d & 0xFF;
                            uint8_t dG = (d >> 8) & 0xFF;
                            uint8_t dB = (d >> 16) & 0xFF;
                            uint8_t sR = p & 0xFF;
                            uint8_t sG = (p >> 8) & 0xFF;
                            uint8_t sB = (p >> 16) & 0xFF;
                            uint8_t invA = 255 - a;
                            dst32[i] = ((sR * a + dR * invA) >> 8) | (((sG * a + dG * invA) >> 8) << 8) | (((sB * a + dB * invA) >> 8) << 16) | (255 << 24);
                        }
                    }
                }
            }
        }

        if (deckLinkOutput && videoFrame1 && videoFrame2) {
            int writeBufferIndex = (currentDisplayBuffer.load() + 1) % 2;
            IDeckLinkMutableVideoFrame* frameToWrite = (writeBufferIndex == 0) ? videoFrame1 : videoFrame2;
            void* frameBytes = nullptr;

            if (frameToWrite) {
                if (frameToWrite->GetBytes(&frameBytes) != S_OK) {
                    frameBytes = nullptr;
                }
            }
            
            if (frameBytes != nullptr) {
                uint8_t* hardwareOutputBuffer = mixBuffer;
                if (decklinkOutputSourceId != -1) {
                    std::lock_guard<std::mutex> lock(sourcesLock);
                    if (sources.count(decklinkOutputSourceId)) {
                        hardwareOutputBuffer = sources[decklinkOutputSourceId]->rgbaBuffer;
                    }
                }
                ConvertRGBAToUYVY(hardwareOutputBuffer, (uint8_t*)frameBytes, MIXER_WIDTH, MIXER_HEIGHT);
                currentDisplayBuffer.store(writeBufferIndex);
                deckLinkOutput->DisplayVideoFrameSync(frameToWrite);
            }
        }

#ifdef _WIN32
        if (vcamDirectEnabled) {
            TryOpenVcamSharedMemory();
            if (vcamSharedBuffer) {
                size_t bgraSize = (size_t)(MIXER_WIDTH * MIXER_HEIGHT * 4);
                const uint32_t* pSrc32 = (const uint32_t*)mixBuffer;
                size_t numPixels = (MIXER_WIDTH * MIXER_HEIGHT);
                
                // Convert RGBA to BGRA (RGB32 for Media Foundation)
                for (size_t i = 0; i < numPixels; i++) {
                    uint32_t pixel = pSrc32[i];
                    vcamBgraBuffer[i] = 0xFF000000 | (pixel & 0x0000FF00) | ((pixel & 0x00FF0000) >> 16) | ((pixel & 0x000000FF) << 16);
                }
                
                bool dropped = false;
                if (vcamSharedMutex) {
                    DWORD waitRes = WaitForSingleObject(vcamSharedMutex, 10);
                    if (waitRes == WAIT_OBJECT_0 || waitRes == WAIT_ABANDONED) {
                        memcpy(vcamSharedBuffer, vcamBgraBuffer, bgraSize);
                        ReleaseMutex(vcamSharedMutex);
                    } else {
                        dropped = true;
                    }
                } else {
                    memcpy(vcamSharedBuffer, vcamBgraBuffer, bgraSize);
                }
                
                if (!dropped && vcamSharedEvent) {
                    SetEvent(vcamSharedEvent);
                }
            }
        } else {
#endif
        if (vcamCallback) {
            size_t rgbaSize = (size_t)(MIXER_WIDTH * MIXER_HEIGHT * 4);
            uint8_t* rgbaBuffer = new uint8_t[rgbaSize];
            memcpy(rgbaBuffer, mixBuffer, rgbaSize);
            auto vcamStatus = vcamCallback.NonBlockingCall(rgbaBuffer, [rgbaSize](Napi::Env env, Napi::Function jsCallback, uint8_t* data) {
                Napi::Buffer<uint8_t> jsBuffer = Napi::Buffer<uint8_t>::Copy(env, data, rgbaSize);
                delete[] data;
                jsCallback.Call({jsBuffer});
            });
            if (vcamStatus != napi_ok) {
                delete[] rgbaBuffer;
            }
        }
#ifdef _WIN32
        }
#endif

        if (previewCallback) {
            DownscaleRGBA(mixBuffer, previewBuffer, MIXER_WIDTH, MIXER_HEIGHT, PREVIEW_WIDTH, PREVIEW_HEIGHT);
            uint8_t* cbBuffer = new uint8_t[PREVIEW_WIDTH * PREVIEW_HEIGHT * 4];
            memcpy(cbBuffer, previewBuffer, PREVIEW_WIDTH * PREVIEW_HEIGHT * 4);
            auto previewStatus = previewCallback.NonBlockingCall(cbBuffer, [](Napi::Env env, Napi::Function jsCallback, uint8_t* data) {
                Napi::Buffer<uint8_t> jsBuffer = Napi::Buffer<uint8_t>::Copy(env, data, PREVIEW_WIDTH * PREVIEW_HEIGHT * 4);
                delete[] data;
                jsCallback.Call({jsBuffer});
            });
            if (previewStatus != napi_ok) {
                delete[] cbBuffer;
            }
        }

        nextFrameTime += std::chrono::milliseconds(33);
        auto now = std::chrono::steady_clock::now();
        if (now > nextFrameTime) {
            // We missed the deadline. If we are far behind, snap the timer to reality
            // so we don't rapid-fire hundreds of frames to catch up.
            nextFrameTime = now;
        } else {
            std::this_thread::sleep_until(nextFrameTime);
        }
    }
    
    delete[] mixBuffer;
    delete[] previewBuffer;
#ifdef _WIN32
    delete[] vcamBgraBuffer;
#endif

#ifdef _WIN32
    CoUninitialize();
#endif
}

Napi::Value StartMixer(const Napi::CallbackInfo& info) {
    if (!isRunning) {
        isRunning = true;
        mixerThread = new std::thread(MixerLoop);
    }
    return info.Env().Undefined();
}

Napi::Value SetProgramSource(const Napi::CallbackInfo& info) {
    if (info.Length() > 0 && info[0].IsNumber()) programSourceId = info[0].As<Napi::Number>().Int32Value();
    return info.Env().Undefined();
}

Napi::Value SetDecklinkOutputSource(const Napi::CallbackInfo& info) {
    if (info.Length() > 0 && info[0].IsNumber()) decklinkOutputSourceId = info[0].As<Napi::Number>().Int32Value();
    return info.Env().Undefined();
}

Napi::Value SetPipSource(const Napi::CallbackInfo& info) {
    if (info.Length() > 1 && info[0].IsNumber() && info[1].IsBoolean()) {
        pipSourceId = info[0].As<Napi::Number>().Int32Value();
        isPipEnabled = info[1].As<Napi::Boolean>().Value();
    }
    return info.Env().Undefined();
}

Napi::Value AddSource(const Napi::CallbackInfo& info) {
    if (info.Length() > 0 && info[0].IsNumber()) {
        int id = info[0].As<Napi::Number>().Int32Value();
        std::lock_guard<std::mutex> lock(sourcesLock);
        if (!sources.count(id)) sources[id] = new VideoSource(id);
    }
    return info.Env().Undefined();
}

Napi::Value PushSourceFrame(const Napi::CallbackInfo& info) {
    if (info.Length() < 2 || !info[0].IsNumber() || !info[1].IsBuffer()) return info.Env().Undefined();
    int id = info[0].As<Napi::Number>().Int32Value();
    Napi::Buffer<uint8_t> buffer = info[1].As<Napi::Buffer<uint8_t>>();
    int srcW = info.Length() > 2 && info[2].IsNumber() ? info[2].As<Napi::Number>().Int32Value() : MIXER_WIDTH;
    int srcH = info.Length() > 3 && info[3].IsNumber() ? info[3].As<Napi::Number>().Int32Value() : MIXER_HEIGHT;
    
    VideoSource* src = nullptr;
    {
        std::lock_guard<std::mutex> lock(sourcesLock);
        if (sources.count(id)) {
            src = sources[id];
        }
    }
    if (src) {
        std::lock_guard<std::mutex> srcLock(src->lock);
        
        uint8_t* inData = buffer.Data();
        size_t expectedSize = srcW * srcH * 4;
        
        if (buffer.Length() >= expectedSize) {
            if (srcW == MIXER_WIDTH && srcH == MIXER_HEIGHT) {
                memcpy(src->rgbaBuffer, inData, expectedSize);
            } else {
                // Nearest neighbor scale to MIXER_WIDTH x MIXER_HEIGHT
                float xRatio = (float)srcW / (float)MIXER_WIDTH;
                float yRatio = (float)srcH / (float)MIXER_HEIGHT;
                for (int y = 0; y < MIXER_HEIGHT; y++) {
                    int sy = (int)(y * yRatio);
                    for (int x = 0; x < MIXER_WIDTH; x++) {
                        int sx = (int)(x * xRatio);
                        int outIdx = (y * MIXER_WIDTH + x) * 4;
                        int inIdx = (sy * srcW + sx) * 4;
                        src->rgbaBuffer[outIdx] = inData[inIdx];
                        src->rgbaBuffer[outIdx+1] = inData[inIdx+1];
                        src->rgbaBuffer[outIdx+2] = inData[inIdx+2];
                        src->rgbaBuffer[outIdx+3] = 255;
                    }
                }
            }
        }
    }
    return info.Env().Undefined();
}


Napi::Value EnableDirectVcam(const Napi::CallbackInfo& info) {
    Napi::Env env = info.Env();
    if (info.Length() > 0 && info[0].IsBoolean()) {
        vcamDirectEnabled = info[0].As<Napi::Boolean>().Value();
    }
    return env.Undefined();
}

Napi::Value SetVcamCallback(const Napi::CallbackInfo& info) {
    if (info.Length() > 0 && info[0].IsFunction()) {
        vcamCallback = Napi::ThreadSafeFunction::New(info.Env(), info[0].As<Napi::Function>(), "VcamCallback", 1, 1);
    }
    return info.Env().Undefined();
}

Napi::Value SetPreviewCallback(const Napi::CallbackInfo& info) {
    if (info.Length() > 0 && info[0].IsFunction()) {
        previewCallback = Napi::ThreadSafeFunction::New(info.Env(), info[0].As<Napi::Function>(), "PreviewCallback", 1, 1);
    }
    return info.Env().Undefined();
}

Napi::String StartDeckLinkOutput(const Napi::CallbackInfo& info) {
    Napi::Env env = info.Env();
    int targetIndex = 0;
    if (info.Length() > 0 && info[0].IsNumber()) {
        targetIndex = info[0].As<Napi::Number>().Int32Value();
    }
    
    if (deckLinkOutput) return Napi::String::New(env, "Already running");
#ifdef _WIN32
    CoInitializeEx(NULL, COINIT_MULTITHREADED);
#endif
    IDeckLinkIterator* deckLinkIterator = nullptr;
#ifdef _WIN32
    if (CoCreateInstance(CLSID_CDeckLinkIterator, NULL, CLSCTX_ALL, IID_IDeckLinkIterator, (void**)&deckLinkIterator) != S_OK) {
        return Napi::String::New(env, "Failed to create DeckLink Iterator");
    }
#else
    deckLinkIterator = CreateDeckLinkIteratorInstance();
    if (!deckLinkIterator) return Napi::String::New(env, "Failed to create DeckLink Iterator");
#endif

    IDeckLink* deckLink = nullptr;
    int idx = 0;
    while (deckLinkIterator->Next(&deckLink) == S_OK) {
        if (idx == targetIndex) break;
        deckLink->Release();
        deckLink = nullptr;
        idx++;
    }
    if (!deckLink) {
        deckLinkIterator->Release();
        return Napi::String::New(env, "No DeckLink device found");
    }
    deckLinkIterator->Release();

    if (deckLink->QueryInterface(IID_IDeckLinkOutput, (void**)&deckLinkOutput) != S_OK) {
        deckLink->Release();
        return Napi::String::New(env, "Device does not support output");
    }
    deckLink->Release();

    HRESULT hr = deckLinkOutput->EnableVideoOutput(bmdModeHD1080p30, bmdVideoOutputFlagDefault);
    if (hr != S_OK) {
        deckLinkOutput->Release();
        deckLinkOutput = nullptr;
        return Napi::String::New(env, "Failed to enable video output");
    }

    HRESULT hr1 = deckLinkOutput->CreateVideoFrame(1920, 1080, 1920 * 2, bmdFormat8BitYUV, bmdFrameFlagDefault, &videoFrame1);
    HRESULT hr2 = deckLinkOutput->CreateVideoFrame(1920, 1080, 1920 * 2, bmdFormat8BitYUV, bmdFrameFlagDefault, &videoFrame2);
    if (hr1 != S_OK || hr2 != S_OK || !videoFrame1 || !videoFrame2) {
        if (videoFrame1) { videoFrame1->Release(); videoFrame1 = nullptr; }
        if (videoFrame2) { videoFrame2->Release(); videoFrame2 = nullptr; }
        deckLinkOutput->Release();
        deckLinkOutput = nullptr;
        return Napi::String::New(env, "Failed to allocate video frames");
    }

    return Napi::String::New(env, "DeckLink Output Connected!");
}

Napi::String StartDeckLinkInput(const Napi::CallbackInfo& info) {
    Napi::Env env = info.Env();
    if (info.Length() < 2 || !info[0].IsNumber() || !info[1].IsNumber()) return Napi::String::New(env, "Invalid args");
    
    int deviceIndex = info[0].As<Napi::Number>().Int32Value();
    int sourceId = info[1].As<Napi::Number>().Int32Value();

#ifdef _WIN32
    CoInitializeEx(NULL, COINIT_MULTITHREADED);
#endif
    IDeckLinkIterator* deckLinkIterator = nullptr;
#ifdef _WIN32
    if (CoCreateInstance(CLSID_CDeckLinkIterator, NULL, CLSCTX_ALL, IID_IDeckLinkIterator, (void**)&deckLinkIterator) != S_OK) {
        return Napi::String::New(env, "Failed to create DeckLink Iterator");
    }
#else
    deckLinkIterator = CreateDeckLinkIteratorInstance();
    if (!deckLinkIterator) return Napi::String::New(env, "Failed to create DeckLink Iterator");
#endif

    IDeckLink* deckLink = nullptr;
    int idx = 0;
    while (deckLinkIterator->Next(&deckLink) == S_OK) {
        if (idx == deviceIndex) break;
        deckLink->Release();
        deckLink = nullptr;
        idx++;
    }
    deckLinkIterator->Release();

    if (!deckLink) return Napi::String::New(env, "DeckLink device index not found");

    IDeckLinkInput* deckLinkInput = nullptr;
    if (deckLink->QueryInterface(IID_IDeckLinkInput, (void**)&deckLinkInput) != S_OK) {
        deckLink->Release();
        return Napi::String::New(env, "Device does not support input");
    }
    deckLink->Release();

    if (activeDeckLinkInputs.count(sourceId) && activeDeckLinkInputs[sourceId]) {
        // Already running this source. No need to restart the hardware.
        return Napi::String::New(env, "Already started");
    }

    // Ensure source buffer is allocated
    {
        std::lock_guard<std::mutex> lock(sourcesLock);
        if (!sources.count(sourceId)) {
            sources[sourceId] = new VideoSource(sourceId);
        }
        if (programSourceId == -1) {
            programSourceId = sourceId;
        }
    }

    DeckLinkInputCallback* callback = new DeckLinkInputCallback(sourceId, deckLinkInput);
    deckLinkInput->SetCallback(callback);

    BMDDisplayMode targetMode = bmdModeHD1080p25;
    bool autoDetect = false;

    if (info.Length() >= 3 && info[2].IsString()) {
        std::string fmt = info[2].As<Napi::String>().Utf8Value();
        std::string s = fmt;
        std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c){ return std::tolower(c); });

        if (s == "auto" || s.empty()) {
            autoDetect = true;
        } else if (s.find("1080p25") != std::string::npos || s.find("1080p 25") != std::string::npos || s.find("25.00p") != std::string::npos || s.find("25p") != std::string::npos || s.find("@25") != std::string::npos || s == "25") {
            targetMode = bmdModeHD1080p25;
        } else if (s.find("1080p50") != std::string::npos || s.find("1080p 50") != std::string::npos || s.find("50.00p") != std::string::npos || s.find("50p") != std::string::npos || s.find("@50") != std::string::npos || s == "50") {
            targetMode = bmdModeHD1080p50;
        } else if (s.find("1080i50") != std::string::npos || s.find("50.00i") != std::string::npos || s.find("50i") != std::string::npos) {
            targetMode = bmdModeHD1080i50;
        } else if (s.find("1080p60") != std::string::npos || s.find("1080p 60") != std::string::npos || s.find("60.00p") != std::string::npos || s.find("60p") != std::string::npos || s.find("@60") != std::string::npos || s == "60") {
            targetMode = bmdModeHD1080p6000;
        } else if (s.find("59.94p") != std::string::npos || s.find("5994") != std::string::npos || s.find("59.94") != std::string::npos) {
            if (s.find("720") != std::string::npos) targetMode = bmdModeHD720p5994;
            else if (s.find("i") != std::string::npos) targetMode = bmdModeHD1080i5994;
            else targetMode = bmdModeHD1080p5994;
        } else if (s.find("1080i60") != std::string::npos || s.find("60i") != std::string::npos || s.find("60.00i") != std::string::npos) {
            targetMode = bmdModeHD1080i6000;
        } else if (s.find("1080p30") != std::string::npos || s.find("30p") != std::string::npos || s.find("@30") != std::string::npos || s == "30") {
            targetMode = bmdModeHD1080p30;
        } else if (s.find("29.97") != std::string::npos || s.find("2997") != std::string::npos) {
            targetMode = bmdModeHD1080p2997;
        } else if (s.find("1080p24") != std::string::npos || s.find("24p") != std::string::npos || s.find("@24") != std::string::npos || s == "24") {
            targetMode = bmdModeHD1080p24;
        } else if (s.find("23.98") != std::string::npos || s.find("2398") != std::string::npos) {
            targetMode = bmdModeHD1080p2398;
        } else if (s.find("720p50") != std::string::npos) {
            targetMode = bmdModeHD720p50;
        } else if (s.find("720p60") != std::string::npos) {
            targetMode = bmdModeHD720p60;
        } else if (s.find("2160p25") != std::string::npos || s.find("4k25") != std::string::npos || s.find("4k 25") != std::string::npos) {
            targetMode = bmdMode4K2160p25;
        } else if (s.find("2160p50") != std::string::npos || s.find("4k50") != std::string::npos || s.find("4k 50") != std::string::npos) {
            targetMode = bmdMode4K2160p50;
        } else if (s.find("2160p60") != std::string::npos || s.find("4k60") != std::string::npos || s.find("4k 60") != std::string::npos) {
            targetMode = bmdMode4K2160p60;
        } else if (s.find("2160p30") != std::string::npos || s.find("4k30") != std::string::npos || s.find("4k 30") != std::string::npos) {
            targetMode = bmdMode4K2160p30;
        } else {
            targetMode = bmdModeHD1080p25;
        }
    }

    HRESULT hr = E_FAIL;
    if (autoDetect) {
        BMDDisplayMode probeModes[] = {
            bmdModeHD1080p25,
            bmdModeHD1080p50,
            bmdModeHD1080i50,
            bmdModeHD1080p5994,
            bmdModeHD1080p6000,
            bmdModeHD1080i5994,
            bmdModeHD1080p30,
            bmdModeHD1080p2997,
            bmdModeHD720p50,
            bmdModeHD720p60,
            bmdModeHD720p5994
        };
        for (BMDDisplayMode probe : probeModes) {
            hr = deckLinkInput->EnableVideoInput(probe, bmdFormat8BitYUV, bmdVideoInputEnableFormatDetection);
            if (hr == S_OK) break;
        }
        if (hr != S_OK) {
            hr = deckLinkInput->EnableVideoInput(bmdModeHD1080p25, bmdFormat8BitYUV, bmdVideoInputFlagDefault);
        }
        if (hr != S_OK) {
            hr = deckLinkInput->EnableVideoInput(bmdModeHD1080p50, bmdFormat8BitYUV, bmdVideoInputFlagDefault);
        }
        if (hr != S_OK) {
            hr = deckLinkInput->EnableVideoInput(bmdModeHD1080p5994, bmdFormat8BitYUV, bmdVideoInputFlagDefault);
        }
    } else {
        hr = deckLinkInput->EnableVideoInput(targetMode, bmdFormat8BitYUV, bmdVideoInputFlagDefault);
        if (hr != S_OK) {
            hr = deckLinkInput->EnableVideoInput(targetMode, bmdFormat8BitYUV, bmdVideoInputEnableFormatDetection);
        }
    }

    if (hr != S_OK) {
        deckLinkInput->Release();
        return Napi::String::New(env, "Failed to enable video input");
    }

    activeDeckLinkInputs[sourceId] = deckLinkInput;
    deckLinkInput->StartStreams();
    return Napi::String::New(env, "DeckLink Input Connected!");
}

Napi::Value GetDeckLinkDevices(const Napi::CallbackInfo& info) {
    Napi::Env env = info.Env();
    Napi::Array devices = Napi::Array::New(env);

#ifdef _WIN32
    CoInitializeEx(NULL, COINIT_MULTITHREADED);
#endif
    IDeckLinkIterator* deckLinkIterator = nullptr;
#ifdef _WIN32
    if (CoCreateInstance(CLSID_CDeckLinkIterator, NULL, CLSCTX_ALL, IID_IDeckLinkIterator, (void**)&deckLinkIterator) != S_OK) {
        return devices;
    }
#else
    deckLinkIterator = CreateDeckLinkIteratorInstance();
    if (!deckLinkIterator) return devices;
#endif

    IDeckLink* deckLink = nullptr;
    int idx = 0;
    while (deckLinkIterator->Next(&deckLink) == S_OK) {
        Napi::Object deviceObj = Napi::Object::New(env);
        deviceObj.Set("index", idx);
        
#ifdef _WIN32
        BSTR deviceNameBSTR = nullptr;
        if (deckLink->GetDisplayName(&deviceNameBSTR) == S_OK) {
            int len = SysStringLen(deviceNameBSTR);
            int utf8Len = WideCharToMultiByte(CP_UTF8, 0, deviceNameBSTR, len, NULL, 0, NULL, NULL);
            if (utf8Len > 0) {
                std::string utf8Name(utf8Len, '\0');
                WideCharToMultiByte(CP_UTF8, 0, deviceNameBSTR, len, &utf8Name[0], utf8Len, NULL, NULL);
                deviceObj.Set("name", utf8Name);
            } else {
                deviceObj.Set("name", "DeckLink Device " + std::to_string(idx + 1));
            }
            SysFreeString(deviceNameBSTR);
        } else {
            deviceObj.Set("name", "DeckLink Device " + std::to_string(idx + 1));
        }

        // Check input support
        IDeckLinkInput* testInput = nullptr;
        if (deckLink->QueryInterface(IID_IDeckLinkInput, (void**)&testInput) == S_OK) {
            deviceObj.Set("supportsInput", true);
            testInput->Release();
        } else {
            deviceObj.Set("supportsInput", false);
        }

        // Check output support
        IDeckLinkOutput* testOutput = nullptr;
        if (deckLink->QueryInterface(IID_IDeckLinkOutput, (void**)&testOutput) == S_OK) {
            deviceObj.Set("supportsOutput", true);
            testOutput->Release();
        } else {
            deviceObj.Set("supportsOutput", false);
        }
#else
        deviceObj.Set("name", "DeckLink Device " + std::to_string(idx + 1));
        deviceObj.Set("supportsInput", true);
        deviceObj.Set("supportsOutput", true);
#endif
        
        devices.Set(idx, deviceObj);
        
        deckLink->Release();
        deckLink = nullptr;
        idx++;
    }
    deckLinkIterator->Release();

    return devices;
}


Napi::Value GetSourceFrame(const Napi::CallbackInfo& info) {
    Napi::Env env = info.Env();
    if (info.Length() < 1) return env.Null();
    int id = info[0].As<Napi::Number>().Int32Value();
    
    std::lock_guard<std::mutex> lock(sourcesLock);
    if (!sources.count(id) || !sources[id]) return env.Null();
    auto* src = sources[id];
    
    std::lock_guard<std::mutex> srcLock(src->lock);
    if (!src->rgbaBuffer) return env.Null();
    
    return Napi::Buffer<uint8_t>::Copy(env, src->rgbaBuffer, MIXER_WIDTH * MIXER_HEIGHT * 4);
}

void Cleanup(void* arg) {
    if (isRunning) {
        isRunning = false;
        if (mixerThread && mixerThread->joinable()) {
            mixerThread->join();
            delete mixerThread;
            mixerThread = nullptr;
        }
    }
    
    if (videoFrame1) { videoFrame1->Release(); videoFrame1 = nullptr; }
    if (videoFrame2) { videoFrame2->Release(); videoFrame2 = nullptr; }
    
    if (deckLinkOutput) {
        deckLinkOutput->DisableVideoOutput();
        deckLinkOutput->Release();
        deckLinkOutput = nullptr;
    }
    
    for (auto& pair : activeDeckLinkInputs) {
        if (pair.second) {
            pair.second->StopStreams();
            pair.second->DisableVideoInput();
            pair.second->SetCallback(nullptr);
            pair.second->Release();
        }
    }
    activeDeckLinkInputs.clear();
}

Napi::Object Init(Napi::Env env, Napi::Object exports) {
    napi_add_env_cleanup_hook(env, Cleanup, nullptr);
    exports.Set(Napi::String::New(env, "getDeckLinkDevices"), Napi::Function::New(env, GetDeckLinkDevices));
    exports.Set(Napi::String::New(env, "startMixer"), Napi::Function::New(env, StartMixer));
    exports.Set(Napi::String::New(env, "startDeckLinkOutput"), Napi::Function::New(env, StartDeckLinkOutput));
    exports.Set(Napi::String::New(env, "startDeckLinkInput"), Napi::Function::New(env, StartDeckLinkInput));
    exports.Set(Napi::String::New(env, "setProgramSource"), Napi::Function::New(env, SetProgramSource));
    exports.Set(Napi::String::New(env, "setDecklinkOutputSource"), Napi::Function::New(env, SetDecklinkOutputSource));
    exports.Set(Napi::String::New(env, "setPipSource"), Napi::Function::New(env, SetPipSource));
    exports.Set(Napi::String::New(env, "addSource"), Napi::Function::New(env, AddSource));
    exports.Set(Napi::String::New(env, "pushSourceFrame"), Napi::Function::New(env, PushSourceFrame));
    exports.Set(Napi::String::New(env, "setPreviewCallback"), Napi::Function::New(env, SetPreviewCallback));
    exports.Set(Napi::String::New(env, "getSourceFrame"), Napi::Function::New(env, GetSourceFrame));
    exports.Set(Napi::String::New(env, "enableDirectVcam"), Napi::Function::New(env, EnableDirectVcam));
    exports.Set(Napi::String::New(env, "setVcamCallback"), Napi::Function::New(env, SetVcamCallback));
    return exports;
}

NODE_API_MODULE(decklink, Init)
