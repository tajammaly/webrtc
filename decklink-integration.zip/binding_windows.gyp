{
  "targets": [
    {
      "target_name": "decklink",
      "sources": [
        "src/decklink/addon.cpp"
      ],
      "include_dirs": [
        "<!@(node -p \"require('node-addon-api').include\")",
        "BlackmagicSDK/Win/include"
      ],
      "cflags!": [
        "-fno-exceptions"
      ],
      "cflags_cc!": [
        "-fno-exceptions"
      ],
      "defines": [
        "NAPI_DISABLE_CPP_EXCEPTIONS"
      ],
      "conditions": [
        [
          "OS=='win'",
          {
            "sources": [
              "BlackmagicSDK/Win/include/DeckLinkAPI_i.c"
            ],
            "libraries": [
              "ole32.lib",
              "oleaut32.lib"
            ],
            "msvs_settings": {
              "VCCLCompilerTool": {
                "ExceptionHandling": 1,
                "WholeProgramOptimization": "false",
                "AdditionalOptions": [
                  "/std:c++17"
                ]
              },
              "VCLinkerTool": {
                "LinkTimeCodeGeneration": 0
              }
            }
          }
        ]
      ]
    }
  ]
}